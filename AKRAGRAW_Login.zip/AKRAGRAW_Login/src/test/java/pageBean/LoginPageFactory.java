package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfuserName;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfuserPwd;
	
	@FindBy(xpath="//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement pfbutton;

	//Initializing Elements
	public LoginPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Setters
	public void setPfuserName(String suserName) {
		pfuserName.sendKeys(suserName);
	}

	public void setPfuserPwd(String suserPwd) {
		pfuserPwd.sendKeys(suserPwd);
	}
	
	public void setPfbutton() {
		pfbutton.click();
	}
	
	//Getters
	public WebElement getPfuserName() {
		return pfuserName;
	}
	
	public WebElement getPfuserPwd() {
		return pfuserPwd;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

}
