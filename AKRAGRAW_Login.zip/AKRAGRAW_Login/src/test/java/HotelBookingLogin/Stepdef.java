package HotelBookingLogin;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.LoginPageFactory;

public class Stepdef {

	private WebDriver driver;
	private WebElement element;
	private LoginPageFactory objlpf;
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AKRAGRAW\\Desktop\\aa\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objlpf = new LoginPageFactory(driver);
		driver.get("file:///C:/Users/AKRAGRAW/Desktop/aa/login.html");
	}

	@When("^User enters correct username and Password$")
	public void user_enters_correct_username_and_Password() throws Throwable {
		
		objlpf.setPfuserName("capgemini"); Thread.sleep(1000);
		objlpf.setPfuserPwd("capg1234"); Thread.sleep(1000);
		objlpf.setPfbutton();
	}

	@Then("^Navigate to the hotel booking page$")
	public void navigate_to_the_hotel_booking_page() throws Throwable {
		
		driver.navigate().to("file:///C:/Users/AKRAGRAW/Desktop/aa/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^User leaves UserName blank$")
	public void user_leaves_UserName_blank() throws Throwable {
		
		objlpf.setPfuserName(""); Thread.sleep(1000);
		objlpf.setPfuserPwd("capg1234"); Thread.sleep(1000);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
		
		objlpf.setPfbutton();
	}

	@Then("^Display error message for UserName$")
	public void display_error_message_for_UserName() throws Throwable {
	  
		element = driver.findElement(By.xpath("//*[@id='userErrMsg']"));
        String userErrMsg=element.getText();
        System.out.println(userErrMsg);
	}

	@When("^User leaves Password blank$")
	public void user_leaves_Password_blank() throws Throwable {
		
		objlpf.setPfuserName("capgemini"); Thread.sleep(1000);
		objlpf.setPfuserPwd(""); Thread.sleep(1000);
	}

	@Then("^Display error message for Password$")
	public void display_error_message_for_Password() throws Throwable {
	   
		element = driver.findElement(By.xpath("//*[@id='pwdErrMsg']"));
        String pwdErrMsg=element.getText();
        System.out.println(pwdErrMsg);
	}

	@When("^user enters incorrect combinations of UserName and Password and clicks the button$")
	public void user_enters_incorrect_combinations_of_UserName_and_Password_and_clicks_the_button(DataTable arg1) throws Throwable {
		
		List<List<String>> data= arg1.raw();
	    for(int i=0;i<data.size();i++)
	    {
	    	driver.findElement(By.name("userName")).clear();
		    driver.findElement(By.name("userPwd")).clear();
		    objlpf.setPfuserName(data.get(i).get(0));
		    Thread.sleep(500);
		    objlpf.setPfuserPwd(data.get(i).get(1));
		    Thread.sleep(500);
	    }
	    objlpf.setPfbutton();
	}

	@Then("^Display alert message$")
	public void display_alert_message() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("********" + alertMessage+"************");
	    driver.close();
	}



}
