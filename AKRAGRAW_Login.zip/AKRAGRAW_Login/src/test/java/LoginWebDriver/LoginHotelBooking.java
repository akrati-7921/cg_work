package LoginWebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginHotelBooking {

	static WebDriver driver;
	static WebElement element;
	
	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AKRAGRAW\\Desktop\\aa\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/AKRAGRAW/Desktop/aa/login.html");
		try 
		{			
			//Username is blank
			driver.findElement(By.name("userName")).sendKeys("");
			Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("capg1234");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
			Thread.sleep(1000);
			callUserErrMsg();
			
			//Password is blank
			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();
			driver.findElement(By.name("userName")).sendKeys("capgemini");
			Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
			Thread.sleep(1000);
			callPwdErrMsg();
			
			//userName and password both are incorrect
			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();
			driver.findElement(By.name("userName")).sendKeys("akrati");
			Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("akku");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
			Thread.sleep(1000);
			callAlertMsg();
			
			//Correct userName and password
			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();
			driver.findElement(By.name("userName")).sendKeys("capgemini");
			Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("capg1234");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
			Thread.sleep(1000);
			driver.navigate().to("file:///C:/Users/AKRAGRAW/Desktop/aa/hotelbooking.html");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.close();
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	private static void callAlertMsg() throws InterruptedException {
		
        String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("********" + alertMessage+"************");
		
	}

	private static void callPwdErrMsg() throws InterruptedException {
		
		element = driver.findElement(By.xpath("//*[@id='pwdErrMsg']"));
        String pwdErrMsg=element.getText();
        System.out.println(pwdErrMsg);
        Thread.sleep(1000);
	}

	private static void callUserErrMsg() throws InterruptedException {
		element = driver.findElement(By.xpath("//*[@id='userErrMsg']"));
        String userErrMsg=element.getText();
        System.out.println(userErrMsg);
        Thread.sleep(1000);
		
	}

}
